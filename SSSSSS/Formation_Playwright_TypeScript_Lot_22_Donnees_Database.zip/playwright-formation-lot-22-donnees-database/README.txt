FORMATION PLAYWRIGHT TYPESCRIPT - LOT 22
Décompresser puis ouvrir index.html. Utiliser uniquement des environnements et données de test.
