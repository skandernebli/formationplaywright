FORMATION PLAYWRIGHT TYPESCRIPT - LOT 9
Décompresser puis ouvrir index.html. Les tests automatisés ne remplacent pas un audit manuel d accessibilité.
