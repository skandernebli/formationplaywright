FORMATION PLAYWRIGHT TYPESCRIPT - LOT 8
Décompresser puis ouvrir index.html. Vérifier les versions des actions et de l image Docker lors des mises à jour.
