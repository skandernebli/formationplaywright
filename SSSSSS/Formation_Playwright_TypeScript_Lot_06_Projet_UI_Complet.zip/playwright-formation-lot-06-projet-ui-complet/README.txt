FORMATION PLAYWRIGHT TYPESCRIPT - LOT 6
Décompresser puis ouvrir index.html. Le projet est pédagogique et utilise SauceDemo.
