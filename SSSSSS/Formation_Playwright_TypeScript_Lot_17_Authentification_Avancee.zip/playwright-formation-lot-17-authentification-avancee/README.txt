FORMATION PLAYWRIGHT TYPESCRIPT - LOT 17
Décompresser puis ouvrir index.html. Ne jamais committer les états auth, passkeys ou clés privées.
