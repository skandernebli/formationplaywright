FORMATION PLAYWRIGHT TYPESCRIPT - LOT 13
Décompresser puis ouvrir index.html. Les Service Workers sont traités dans un projet Chromium dédié.
