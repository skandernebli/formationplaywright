FORMATION PLAYWRIGHT TYPESCRIPT - LOT 16
Décompresser puis ouvrir index.html. L emulation mobile ne remplace pas tous les tests sur appareils physiques.
