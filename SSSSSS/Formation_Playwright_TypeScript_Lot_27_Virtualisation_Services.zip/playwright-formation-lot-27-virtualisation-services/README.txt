FORMATION PLAYWRIGHT TYPESCRIPT - LOT 27
Decompresser puis ouvrir index.html. Nettoyer tous les HAR avant versionnement.
