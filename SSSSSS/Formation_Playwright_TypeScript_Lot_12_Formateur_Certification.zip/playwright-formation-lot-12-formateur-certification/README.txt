FORMATION PLAYWRIGHT TYPESCRIPT - LOT 12
Décompresser puis ouvrir index.html. Ce lot sert à former, évaluer et certifier les compétences acquises.
