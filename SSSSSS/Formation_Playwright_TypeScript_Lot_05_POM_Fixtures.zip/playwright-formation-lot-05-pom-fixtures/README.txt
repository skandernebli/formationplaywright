FORMATION PLAYWRIGHT TYPESCRIPT - LOT 5
Décompresser puis ouvrir index.html.
