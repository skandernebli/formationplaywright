FORMATION PLAYWRIGHT TYPESCRIPT - LOT 26
Decompresser puis ouvrir index.html. Toujours verifier data et errors dans une reponse GraphQL.
