FORMATION PLAYWRIGHT TYPESCRIPT - LOT 20
Décompresser puis ouvrir index.html. Utilise la fixture mount stable et une galerie servie par le projet.
