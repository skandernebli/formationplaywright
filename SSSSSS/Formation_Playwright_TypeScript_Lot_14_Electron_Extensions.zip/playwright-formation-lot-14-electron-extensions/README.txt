FORMATION PLAYWRIGHT TYPESCRIPT - LOT 14
Décompresser puis ouvrir index.html. Le support Electron Playwright est expérimental.
