# Parcours complet - production par lots

1. Lot 1 : Fondations QA, environnement et TypeScript
2. Lot 2 : Installation Playwright, premier test, exécution et rapports
3. Lot 3 : Locators, assertions, auto-waiting, formulaires et navigation
4. Lot 4 : Debug, traces, réseau, téléchargements, fenêtres et iframes
5. Lot 5 : POM, composants, fixtures, données et authentification
6. Lot 6 : Projet UI Saucedemo complet et exercices corrigés
7. Lot 7 : API CRUD, setup/cleanup et validation AJV
8. Lot 8 : Allure, GitHub Actions, Docker, qualité et portfolio
