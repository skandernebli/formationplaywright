FORMATION PLAYWRIGHT TYPESCRIPT - LOT 15
Décompresser puis ouvrir index.html. Adapter statuts et schemas au contrat réel.
