FORMATION PLAYWRIGHT TYPESCRIPT - LOT 24
Décompresser puis ouvrir index.html. Installer l horloge avant toute API temporelle de la page.
