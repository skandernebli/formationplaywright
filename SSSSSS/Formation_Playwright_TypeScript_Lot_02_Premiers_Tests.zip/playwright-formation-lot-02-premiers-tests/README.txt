FORMATION PLAYWRIGHT TYPESCRIPT - LOT 2

1. Décompresser le ZIP.
2. Ouvrir index.html dans un navigateur.
3. Suivre les chapitres dans l’ordre.
4. Réaliser les exercices avant d’ouvrir les corrections.

Ce lot couvre l’installation, le premier test, l’exécution, la configuration et les outils de diagnostic.
