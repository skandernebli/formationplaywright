FORMATION PLAYWRIGHT TYPESCRIPT - LOT 30
Decompresser puis ouvrir index.html. Examiner tout diff visuel avant mise a jour des baselines.
