FORMATION PLAYWRIGHT TYPESCRIPT - LOT 21
Décompresser puis ouvrir index.html. Utiliser uniquement des fichiers de test synthétiques.
