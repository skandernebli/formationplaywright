FORMATION PLAYWRIGHT TYPESCRIPT - LOT 11
Décompresser puis ouvrir index.html. Ce lot est consacré au pilotage et à la gouvernance de la suite.
