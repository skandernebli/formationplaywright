FORMATION PLAYWRIGHT TYPESCRIPT - LOT 10
Décompresser puis ouvrir index.html. Ce lot avancé suppose la maîtrise des lots 1 à 9.
