FORMATION PLAYWRIGHT TYPESCRIPT - LOT 7
Décompresser puis ouvrir index.html. Adapter les endpoints et statuts au contrat réel.
