FORMATION PLAYWRIGHT TYPESCRIPT - LOT 28
Decompresser puis ouvrir index.html. Utiliser uniquement des tenants de test.
