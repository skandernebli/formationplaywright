FORMATION PLAYWRIGHT TYPESCRIPT - LOT 4

Décompresser, ouvrir index.html, suivre les chapitres et réaliser les ateliers avant les corrections.
