FORMATION PLAYWRIGHT TYPESCRIPT - LOT 3

Ouvrir index.html puis suivre les chapitres dans l ordre. Réaliser les ateliers avant d afficher les corrections.
